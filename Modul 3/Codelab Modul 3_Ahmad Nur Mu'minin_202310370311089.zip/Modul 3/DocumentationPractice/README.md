# Documentation Practice
#This is a simple project to practice creating documentation in a READMEfile.
#
###Usage
#1.Clone the repository to your local machine.
#2.Open the project in your favorite IDE.
#3.Run the program to see the output.
#
###Dependencies
#-None
#
###License
#This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.